const productData = {
"1": {
        id: "1",
        type: "bass",
        name: "Fender Precision Bass",
        price: 2199,
        description: "El bajo Music Man StingRay, conocido por su potente sonido y construcción de alta calidad.",
        specs: [
            "Cuerpo: Fresno",
            "Mástil: Arce tostado",
            "Diapasón: Palisandro",
            "Trastes: 21 trastes de acero inoxidable",
            "Pastillas: 1 x Humbucker",
            "Puente: Puente de acero cromado",
            "Controles: 1 x Volumen, 1 x Tono, EQ de 3 bandas"
        ],
        images: [
            "https://kcjjsxmxrjqjxjwqjqvb.supabase.co/storage/v1/object/public/images/bass1.jpg",
            "https://kcjjsxmxrjqjxjwqjqvb.supabase.co/storage/v1/object/public/images/bass1_detail1.jpg",
            "https://kcjjsxmxrjqjxjwqjqvb.supabase.co/storage/v1/object/public/images/bass1_detail2.jpg"
        ]
    }
    // Agrega más productos aquí...
    
        }
};
